LiftLab Pro Full Demo MVP

Open index.html in a browser.

This MVP includes:
- LiftLab Pro landing page
- Pricing: 1 free render, $10/render, $25/month unlimited
- Truck photo upload
- Build request form matching your Supabase columns
- Saved requests dashboard
- Export JSON
- AI prompt generator for manual or future AI renders

Next production steps:
1. Buy liftlabpro.com
2. Deploy this folder on Vercel
3. Connect Supabase
4. Add Stripe
5. Add OpenAI image generation/editing
